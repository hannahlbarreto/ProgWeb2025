function createLink(url) {
  return `<a href="${url}">${url}</a><br>`;
}

module.exports = {
  createLink,
};
