export function criarLink(url) {
  return `<a href="${url}">${url}</a><br>`;
}