// Controller para Major
