
const UserService = require('../services/user.service');

const UserController = {
  async getAll(req, res) {
    const users = await UserService.getAllUsers();
    res.json(users);
  },

  async getOne(req, res) {
    const user = await UserService.getUserById(req.params.id);
    if (user) {
      res.json(user);
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  },

  async create(req, res) {
    const user = await UserService.createUser(req.body);
    res.status(201).json(user);
  },

  async update(req, res) {
    const user = await UserService.updateUser(req.params.id, req.body);
    res.json(user);
  },

  async remove(req, res) {
    await UserService.deleteUser(req.params.id);
    res.status(204).end();
  }
};

module.exports = UserController;
