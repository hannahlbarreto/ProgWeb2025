// Modelo de Major
