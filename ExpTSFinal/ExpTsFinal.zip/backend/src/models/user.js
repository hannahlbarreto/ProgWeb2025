
const db = require('../db');

const User = {
  async create({ name, email, password, major_id }) {
    const result = await db.query(
      'INSERT INTO users (name, email, password, major_id) VALUES ($1, $2, $3, $4) RETURNING *',
      [name, email, password, major_id]
    );
    return result.rows[0];
  },

  async findAll() {
    const result = await db.query('SELECT * FROM users');
    return result.rows;
  },

  async findById(id) {
    const result = await db.query('SELECT * FROM users WHERE id = $1', [id]);
    return result.rows[0];
  },

  async update(id, { name, email, password, major_id }) {
    const result = await db.query(
      'UPDATE users SET name = $1, email = $2, password = $3, major_id = $4 WHERE id = $5 RETURNING *',
      [name, email, password, major_id, id]
    );
    return result.rows[0];
  },

  async delete(id) {
    await db.query('DELETE FROM users WHERE id = $1', [id]);
  }
};

module.exports = User;
