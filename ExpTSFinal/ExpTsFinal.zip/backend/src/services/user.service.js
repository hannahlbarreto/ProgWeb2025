
const User = require('../models/user');

const UserService = {
  getAllUsers: async () => {
    return await User.findAll();
  },

  getUserById: async (id) => {
    return await User.findById(id);
  },

  createUser: async (userData) => {
    return await User.create(userData);
  },

  updateUser: async (id, userData) => {
    return await User.update(id, userData);
  },

  deleteUser: async (id) => {
    return await User.delete(id);
  }
};

module.exports = UserService;
