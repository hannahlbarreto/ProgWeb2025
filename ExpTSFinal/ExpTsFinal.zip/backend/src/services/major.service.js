// Service para Major
