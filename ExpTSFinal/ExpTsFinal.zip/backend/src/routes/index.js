
const express = require('express');
const router = express.Router();
const UserController = require('../controllers/user.controller');

// Rotas para User
router.get('/users', UserController.getAll);
router.get('/users/:id', UserController.getOne);
router.post('/users', UserController.create);
router.put('/users/:id', UserController.update);
router.delete('/users/:id', UserController.remove);

module.exports = router;
